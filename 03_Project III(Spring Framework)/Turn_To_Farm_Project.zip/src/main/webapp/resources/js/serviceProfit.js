//08.06
document.addEventListener("DOMContentLoaded", function () {

	// 농작물에 해당하는 선택 옵션 설정
	  var cropSelect = document.getElementById("filterSelect");
	  for (var i = 0; i < cropSelect.options.length; i++) {
	    if (cropSelect.options[i].value === crop) {
	      cropSelect.options[i].selected = true;
	      break;
	    }
	  }

	  // 지역명에 해당하는 선택 옵션 설정
	  var regionSelect = document.getElementById("regionSelect");
	  for (var j = 0; j < regionSelect.options.length; j++) {
	    if (regionSelect.options[j].value === area) {
	      regionSelect.options[j].selected = true;
	      break;
	    }
	  }

});



/******************************************************************************/
/** 작물 - 지역 필터**/
// 버튼 목록을 가져옵니다.
const buttonContainer = document.getElementById('buttonContainer');
const filterButtons = document.querySelectorAll('.filterButton');

// 필터링 기준이 되는 셀렉터를 가져옵니다.
const filterSelect = document.getElementById('filterSelect');

// 셀렉터 변경 시 필터링 함수를 호출합니다.
filterSelect.addEventListener('change', filterButtonsByCondition);

// 필터링 함수 정의
function filterButtonsByCondition() {
  const selectedCondition = filterSelect.value;

  // 모든 버튼을 숨깁니다.
  filterButtons.forEach(button => {
    button.style.display = 'none';
  });

  // 선택한 조건에 맞는 버튼만 표시합니다.
  const filteredButtons = document.querySelectorAll(`.${selectedCondition}`);
  filteredButtons.forEach(button => {
    button.style.display = 'block';
  });
}

// 페이지 로드시 기본적으로 전체 버튼을 표시합니다.
filterButtonsByCondition();


/******************************************************************************/

/****************************************/
document.addEventListener("DOMContentLoaded", function() {
	  // 페이지 로드 완료 시 실행될 코드

	  // 검색 버튼 요소를 가져옵니다.
	  var searchButton = document.getElementById("submit_button");
	  
	  console.log("클릭해라");

	  // 검색 버튼을 클릭합니다.
	  searchButton.click();
	});


/****************************************/

const reset_button = document.querySelector("#reset_button")

reset_button.addEventListener("click", ()=>{
  const visualization_text = document.querySelector(".visualization_text")

  visualization_text.innerHTML = "<div class='default_message'>" +"원하는 경작 면적과 추가 노동 인구를 선택하세요."+ "</div>";

  const graph_image = document.querySelector(".graph_image")
  const chart_title = document.querySelector(".chart_title")
  const visualization_graph = document.querySelector(".visualization_graph")
  
  graph_image.style.display = "none"
  chart_title.style.display = "none"
  visualization_graph.style.display = "none"
})