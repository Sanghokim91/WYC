//로그인시 (세션존재) 로그인 -> 로그아웃 / 회원가입 -> 마이페이지
if(sessionId != null){
	const loginNav = document.querySelector(".loginNav");
	const joinNav = document.querySelector(".joinNav");
	const logoutNav = document.querySelector(".logoutNav");
	const myPageNav = document.querySelector(".myPageNav");
	
	loginNav.style.display = "none";
	joinNav.style.display = "none";
	logoutNav.style.display = "block";
	myPageNav.style.display = "block";
}


//JoinMember.jsp
//회원가입 정보 검사
function infoConfirm() {
	if(document.loginForm.id.value.length == 0){
		alert("아이디는 필수 입니다");
		loginForm.id.focus();
		return;
	}
	
	if(document.loginForm.id.value.length < 4){
		alert("아이디는 4글자 이상이어야 합니다");
		loginForm.id.focus();
		return;
	}
	
	if(document.loginForm.pw.value.length == 0){
		alert("비밀번호는 필수사항입니다.");
		loginForm.pw.focus();
		return;
	}
	
	if(document.loginForm.pw.value != document.loginForm.pwCheck.value){
		alert("비밀번호가 일치하지 않습니다.");
		loginForm.pw.focus();
		return;
	}
	
	if(document.loginForm.name.value.length == 0){
		alert("이름은 필수사항입니다.");
		loginForm.name.focus();
		return;
	}
	
	if(document.loginForm.id.value.length == 0){
		alert("아이디는 필수사항입니다");
		loginForm.id.focus();
		return;
	}
	
	if(document.loginForm.eMail.value.length == 0){
		alert("메일은 필수사항 입니다");
		loginForm.eMail.focus();
		return;
	}
	
	document.loginForm.submit();
}




//modify.jsp
//수정 검사
function updateInfoConfirm() {
	if(document.modifyForm.pw.value == ""){
		alert("패스워드를 입력하세요.")
		document.modifyForm.pw.focus();
		return;
	}
	
	if(document.modifyForm.pw.value != document.reg_frm.pw_check.value){
		alert("비밀번호가 일치하지 않습니다.")
		modifyForm.pw.focus();
		return;
	}
	
	if(document.modifyForm.eMail.value.length == 0){
		alert("메일은 필수 입력사항입니다")
		modifyForm.eMail.focus();
		return;
	}
	
	document.modifyForm.submit();
}