var myChart; // 차트 객체를 저장할 변수 선언

        // AJAX를 사용하여 서버로부터 데이터를 받아오는 함수
        function getDataFromServer() {
            $.ajax({
                url: "result.do", // 서버의 URL
                method: "GET", // 폼 데이터를 전송하므로 POST 방식 사용
                dataType: "json",
                data: $("#resultForm").serialize(), // 폼 데이터를 직렬화하여 전송
                success: function(dataArray) {
                    console.log(dataArray);
                	// 데이터를 받아와서 원하는 방식으로 활용 (예: Chart.js를 사용하여 그래프 그리기)
                    drawChart(dataArray);
                    addDataToTable(dataArray);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", error);
                }
            });
        }

        // 차트를 그리는 함수
        function drawChart(data) {
            // 기존 차트가 있으면 삭제
            if (myChart) {
                myChart.destroy();
            }

            var ctx = document.getElementById('myChart').getContext('2d');
            myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['매출', '비용', '정책 지원금', '수익'],
                    datasets: [{
                        label: 'Data',
                        data: data,
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)'
                        ],
                        borderColor: [
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                	maxBarThickness: 100,
                	plugins:{
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    } 
                }
            });
        }
        
     // 데이터를 테이블에 쭉 옆으로 나열되게 추가하는 함수
        function addDataToTable(data) {
            var table = document.getElementById('dataTable');

            // 기존 테이블 데이터 모두 제거
            while (table.rows.length > 1) {
                table.deleteRow(1);
            }

            // 데이터를 테이블에 추가 (옆으로 나열)
            var newRow = table.insertRow();
            data.forEach((value, index) => {
                var newCell = newRow.insertCell();
                var formattedValue = formatNumber(value);
                newCell.textContent = formattedValue;
            });
        }
        
     // 숫자를 원하는 형식으로 포맷팅하는 함수
        function formatNumber(number) {
            return number.toLocaleString('ko-KR') + '원';
        }

        // 폼 제출 버튼 클릭 이벤트 핸들러
        $("#resultForm").submit(function(event) {
            event.preventDefault(); // 폼 기본 제출 동작을 막음
            getDataFromServer(); // AJAX 요청 보내기
        });
        
        
