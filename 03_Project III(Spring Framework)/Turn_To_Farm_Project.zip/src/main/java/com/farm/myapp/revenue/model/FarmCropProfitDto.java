package com.farm.myapp.revenue.model;

public class FarmCropProfitDto {
	private int year;
	private int revenue;
	private double interept;
	private double pcost;
	private double dcost;
	private double temp;
	private double rain;
	private double sun;
	private double insolation;
	private double hprice;
	private double gdp;
	private double area;
	private double yield;
	
	public FarmCropProfitDto() {
	}
	
	public FarmCropProfitDto(double interept, double pcost, double dcost, double temp, double rain, double sun, double insolation, double hprice, double gdp, double area, double yield) {
		this.interept = interept;
		this.pcost = pcost;
		this.dcost = dcost;
		this.temp = temp;
		this.rain = rain;
		this.sun = sun;
		this.insolation = insolation;
		this.hprice = hprice;
		this.gdp = gdp;
		this.area = area;
		this.yield = yield;
		
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getRevenue() {
		return revenue;
	}

	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}

	public double getInterept() {
		return interept;
	}

	public void setInterept(double interept) {
		this.interept = interept;
	}

	public double getPcost() {
		return pcost;
	}

	public void setPcost(double pcost) {
		this.pcost = pcost;
	}

	public double getDcost() {
		return dcost;
	}

	public void setDcost(double dcost) {
		this.dcost = dcost;
	}

	public double getTemp() {
		return temp;
	}

	public void setTemp(double temp) {
		this.temp = temp;
	}

	public double getRain() {
		return rain;
	}

	public void setRain(double rain) {
		this.rain = rain;
	}

	public double getSun() {
		return sun;
	}

	public void setSun(double sun) {
		this.sun = sun;
	}

	public double getInsolation() {
		return insolation;
	}

	public void setInsolation(double insolation) {
		this.insolation = insolation;
	}

	public double getHprice() {
		return hprice;
	}

	public void setHprice(double hprice) {
		this.hprice = hprice;
	}

	public double getGdp() {
		return gdp;
	}

	public void setGdp(double gdp) {
		this.gdp = gdp;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getYield() {
		return yield;
	}

	public void setYield(double yield) {
		this.yield = yield;
	}

	
	
	
	
}
