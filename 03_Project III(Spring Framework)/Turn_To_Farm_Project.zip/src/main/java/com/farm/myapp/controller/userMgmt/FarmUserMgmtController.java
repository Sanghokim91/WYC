package com.farm.myapp.controller.userMgmt;

import java.util.List;

import javax.print.DocFlavor.STRING;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.farm.myapp.userMgmt.model.FarmMemberVO;
import com.farm.myapp.userMgmt.service.IFarmUserMgmtService;

@Controller
//@RequestMapping("/userMgmt")
public class FarmUserMgmtController {
	
	@Autowired
	IFarmUserMgmtService farmUserMgmtService;
	
	//로그인 화면으로 이동
	@RequestMapping("/login.do")
	public String login() {
		return "userMgmt/login";
	}
	
	//회원 로그인 정보 확인
	@PostMapping("/loginService.do")
	public String loginService(@Param("id")String id, @Param("pw")String pw, Model model) {
		System.out.println("loginId : " + id);
		System.out.println("loginPW : " + pw);
		farmUserMgmtService.loginService(id, pw);
		
		return "index";
	}
	
	//회원가입 화면으로 이동
	@RequestMapping("/joinMember.do")
	public String joinMember() {
		return "userMgmt/joinMember";
	}
	
	//회원가입 서비스 실행
	@PostMapping("/joinService.do")
	public String joinService(FarmMemberVO member, Model model) {
		System.out.println("member : " + member);
		farmUserMgmtService.joinService(member);
//		model.addAttribute("ressult", ressult);
		return "userMgmt/login";
	}
	
	//아이디 찾기 화면으로 이동
	@RequestMapping("/find_id.do")
	public String find_id() {
		return "userMgmt/find_id";
	}
	
	//아이디 찾기 서비스 실행
	@GetMapping("/findIdService.do")
	public ModelAndView findIdService(@Param("name")String name, @Param("ssn")String ssn, Model model) {

		FarmMemberVO findId = farmUserMgmtService.findIdService(name, ssn);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("id", findId.getId());
		modelAndView.addObject("name", findId.getName());
		System.out.println("findId.getId() : " + findId.getId());
		System.out.println("findId.getName() : " + findId.getName());
		modelAndView.setViewName("userMgmt/find_id_true");
		return modelAndView;
	}
	
	//아이디 찾기 화면으로 이동
	@RequestMapping("/find_pw.do")
	public String find_pw() {
		return "userMgmt/find_pw";
	}
	
	//아이디 찾기 서비스 실행
	@GetMapping("/findPwService.do")
	public ModelAndView findPwService(@Param("id")String id, @Param("name")String name, @Param("ssn")String ssn, Model model) {
		FarmMemberVO findId = farmUserMgmtService.findPwService(id, name, ssn);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("name", findId.getName());
		modelAndView.addObject("pw", findId.getPw());
		System.out.println("findId.getName() : " + findId.getName());
		System.out.println("findId.getAddress() : " + findId.getAddress());
		modelAndView.setViewName("userMgmt/find_pw_true");
		return modelAndView;
	}
	
	//로그 아웃(세션 제거) 후 index페이지로 이동
	@RequestMapping("/logout.do")
	public String logout() {
		return "userMgmt/logout";
	}

	//마이페이지 접속
	@RequestMapping("/mypage.do")
	public ModelAndView mypage(@Param("id") String id, Model model) {
		System.out.println("mypage : " + id);
		ModelAndView modelAndView = new ModelAndView();
		FarmMemberVO memberInfo = farmUserMgmtService.getMemberInfo(id);
		modelAndView.addObject("memberInfo", memberInfo);
		modelAndView.setViewName("userMgmt/mypage");
		return modelAndView;
	}

	//수정 화면 접속
	@RequestMapping("/modifys.do")
	public ModelAndView modify(@Param("id") String id, Model model) {
		System.out.println("modify 연결 성공 : " + id);
		ModelAndView modelAndView = new ModelAndView();
		FarmMemberVO memberInfo = farmUserMgmtService.getMemberInfo(id);
		modelAndView.addObject("memberInfo", memberInfo);
		modelAndView.setViewName("userMgmt/modify");
		return modelAndView;
	}
	
	//회원 정보 수정 서비스
	@PostMapping("/modifyService.do")
	public String modifyService(@Param("id")String id, @Param("pw")String pw, @Param("address")String address, @Param("eMail")String eMail, Model model) {
		System.out.println("modifyService 연결 성공 : "+id+" : " + pw +" : " +address+ " : "+ eMail);
		farmUserMgmtService.modifyService(id, pw, address, eMail);
		return "redirect:/mypage.do?id="+id;
	}
	
//	@RequestMapping("/mypage.do/modify.jsp")
//	public void modify() {
//		System.out.println("modify 연결 성공 : ");
//		ModelAndView modelAndView = new ModelAndView();
//		FarmMemberVO memberInfo = farmUserMgmtService.getMemberInfo(id);
//		modelAndView.addObject("memberInfo", memberInfo);
//		modelAndView.setViewName("userMgmt/mypage");
//		return modelAndView;
//	}
	
	
	
}
