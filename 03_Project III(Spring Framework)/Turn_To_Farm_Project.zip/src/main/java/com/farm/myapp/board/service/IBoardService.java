package com.farm.myapp.board.service;

import java.util.List;

import com.farm.myapp.board.model.BoardDto;

public interface IBoardService {
	
	void write(BoardDto dto);
	List<BoardDto> list();
	BoardDto contentView(String strID);
	void modify(BoardDto dto);
	void delete(BoardDto dto);
	BoardDto replyView(String strID);
	void reply(BoardDto dto);

}
