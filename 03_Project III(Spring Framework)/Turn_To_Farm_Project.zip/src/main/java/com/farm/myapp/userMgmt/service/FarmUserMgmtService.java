package com.farm.myapp.userMgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.farm.myapp.userMgmt.dao.IFarmUserMgmtRepository;
import com.farm.myapp.userMgmt.model.FarmMemberVO;

@Service
public class FarmUserMgmtService implements IFarmUserMgmtService {
	
	@Autowired
	IFarmUserMgmtRepository farmUserMgmtRepository;

	@Override
	public void joinService(FarmMemberVO member) {
		farmUserMgmtRepository.joinService(member);
	}

	@Override
	public void loginService(String id, String pw) {
		farmUserMgmtRepository.loginService(id, pw);
	}

	@Override
	public FarmMemberVO findIdService(String name, String ssn) {
		return farmUserMgmtRepository.findIdService(name, ssn);
	}

	@Override
	public FarmMemberVO findPwService(String id, String name, String ssn) {
		return farmUserMgmtRepository.findPwService(id, name, ssn);
	}

	@Override
	public FarmMemberVO getMemberInfo(String id) {
		return farmUserMgmtRepository.getMemberInfo(id);
	}

	@Override
	public void modifyService(String id, String pw, String address, String eMail) {
		farmUserMgmtRepository.modifyService(id, pw, address, eMail);
	}

}
