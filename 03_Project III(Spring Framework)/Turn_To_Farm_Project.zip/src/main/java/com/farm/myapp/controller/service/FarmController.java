package com.farm.myapp.controller.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.farm.myapp.cost.model.Dto;
import com.farm.myapp.cost.service.ICostService;
import com.farm.myapp.profit.model.Dtos;
import com.farm.myapp.profit.service.IProfitService;
import com.farm.myapp.revenue.model.FarmAreaCropDto;
import com.farm.myapp.revenue.model.FarmCropAreaDto;
import com.farm.myapp.revenue.model.FarmCropDto;
import com.farm.myapp.revenue.model.FarmCropInfoDto;
import com.farm.myapp.revenue.model.FarmCropProfileDto;
import com.farm.myapp.revenue.model.FarmCropProfitDto;
import com.farm.myapp.revenue.service.IRevenueService;

@Controller
public class FarmController {
	
	@Autowired
	IRevenueService revenueService;
	
	@RequestMapping(value="/")
	public String home(Model model) {
		return "/index";
	}
	
	@RequestMapping(value="/index.do") // 메인 페이지로 이동
	public String index(Model model) {
		return "/index";
	}
	
	@RequestMapping(value="/revenue1.do") //농작물 우선 매출 페이지로 이동, 농작물 리스트 표시
	public String revenue1(Model model) {
		List<FarmCropDto> cropList = revenueService.cropList();
		model.addAttribute("cropList", cropList);
		return "/revenue1";
	}
	
	@RequestMapping(value="/cropArea.do") //재배가능지역 출력
	public @ResponseBody List<FarmCropAreaDto> cropArea(@RequestParam(value="crop", required=false, defaultValue="0") String selectedCrop, Model model) {
		List<FarmCropAreaDto> cropAreaList = revenueService.cropAreaList(selectedCrop);
		return cropAreaList;
	}
	
	@RequestMapping(value="/salesText.do") //매출 확인
	public @ResponseBody List<Integer> getCropInfo(@RequestParam(value="selectCrop", required=false, defaultValue="0") String selectedCrop, Model model) {
		List<FarmCropInfoDto> getCropInfo = revenueService.getCropInfo(selectedCrop);
		Double pcost = getCropInfo.get(0).getPcost();
		Double dcost = getCropInfo.get(0).getDcost();
		Double temp = getCropInfo.get(0).getTemp();
		Double rain = getCropInfo.get(0).getRain();
		Double sun = getCropInfo.get(0).getSun();
		Double insolation = getCropInfo.get(0).getInsolation();
		Double hprice = getCropInfo.get(0).getHprice();
		Double gdp = getCropInfo.get(0).getGdp();
		Double area = getCropInfo.get(0).getArea();
		Double yield = getCropInfo.get(0).getYield();
		
		List<FarmCropProfitDto> getCropProfit = revenueService.getCropProfit(selectedCrop);
		Double intereptP = getCropProfit.get(0).getInterept();
		Double pcostP = getCropProfit.get(0).getPcost();
		Double dcostP = getCropProfit.get(0).getDcost();
		Double tempP = getCropProfit.get(0).getTemp();
		Double rainP = getCropProfit.get(0).getRain();
		Double sunP = getCropProfit.get(0).getSun();
		Double insolationP = getCropProfit.get(0).getInsolation();
		Double hpriceP = getCropProfit.get(0).getHprice();
		Double gdpP = getCropProfit.get(0).getGdp();
		Double areaP = getCropProfit.get(0).getArea();
		Double yieldP = getCropProfit.get(0).getYield();
		
		Double cropPredictionValueDouble = intereptP + (pcost*pcostP) + (dcost*dcostP) + (temp*tempP) + (rain*rainP) + (sun+sunP) +
				(insolation*insolationP) + (hprice*hpriceP) + (gdp+gdpP) + (area*areaP) + (yield*yieldP);
		
		System.out.println("결과" + cropPredictionValueDouble);
		
		int cropPredictionValue = (int) Math.round(cropPredictionValueDouble); 
		
		System.out.println("pcostp" + pcostP);
		System.out.println(cropPredictionValue);
		
		List<Integer> getRevenues = revenueService.getRevenues(selectedCrop);
		getRevenues.add(cropPredictionValue);
		
		System.out.println(getRevenues);
		
		return getRevenues;
	}
	
	@RequestMapping(value="/revenue2.do") //지역 우선 매출분석 페이지로 이동
	public String revenue2(Model model) {
		return "/revenue2";
	}
	
	@RequestMapping(value="/getAreaCropList.do") //지역 선택시 농작물 리스트 출력
	public @ResponseBody List<FarmAreaCropDto> getAreaCrop(@RequestParam(value="areaCrop", required=false, defaultValue="0") String areaName, Model model) {
		List<FarmAreaCropDto> getAreaCrop = revenueService.getAreaCrop(areaName);
		System.out.println(getAreaCrop);
		
		return getAreaCrop;
	}
	
	@RequestMapping(value="/getCropProfile.do") //지역, 농작물 선택시 농작물 정보 출력
	public @ResponseBody ArrayList<String> getCropProfile(@RequestParam(value="selectCrop", required=false, defaultValue="0") String selectedCrop, Model model) {
		List<FarmCropProfileDto> getCropProfile = revenueService.getCropProfile(selectedCrop);
		
		String cropName = getCropProfile.get(0).getCropName();
		String cropKor = getCropProfile.get(0).getCropKor();
		String cropVariety = getCropProfile.get(0).getCropVariety();
		String cropGrow = getCropProfile.get(0).getCropGrow();
		String cropSpecial = getCropProfile.get(0).getCropSpecial();
		
		ArrayList<String> cropProfileList = new ArrayList<String>();
		
		cropProfileList.add(cropName);
		cropProfileList.add(cropKor);
		cropProfileList.add(cropVariety);
		cropProfileList.add(cropGrow);
		cropProfileList.add(cropSpecial);
		
		System.out.println(cropProfileList);
		
		return cropProfileList;
	}
	
	@RequestMapping(value="/getCropHpriceYield.do") // 경매단가, 생산량 정보 출력
	public @ResponseBody List<List<String>> getHpriceYield(@RequestParam(value="selectCrop", required=false, defaultValue="0") String selectedCrop, Model model){
		List<List<String>> getHpriceYield = revenueService.getHpriceYield(selectedCrop);
		System.out.println(getHpriceYield);
		return getHpriceYield;
	}
	
	@RequestMapping(value="/serviceCosts.do") // 매출분석에서 선택한 농작물, 지역 데이터를 가지고 비용분석 페이지로 이동
    public String serviceCosts(@RequestParam("selectCropKor") String crop, @RequestParam("areaKor") String area, HttpServletRequest request, HttpSession session, Model model){
        String cropSession = crop;
        String areaSession = area.trim();

        model.addAttribute("crop", crop);
        model.addAttribute("area", area);
        
        System.out.println(crop);
        System.out.println(area);

        session.setAttribute("cropSession", cropSession);
        session.setAttribute("areaSession", areaSession);
        
        return "/serviceCost";
    }
	
	@RequestMapping(value="/serviceCost.do") //비용 조회 페이지로 이동
	public String serviceCost(Model model) {
		return "/serviceCost";
	}
	
	@RequestMapping(value="/serviceProfit.do") //수익 확인 페이지로 이동
	public String serviceProfit(Model model) {
		return "/serviceProfit";
	}
	
	@Autowired
	ICostService costService;
	
	@RequestMapping(value="/select.do") // 비용 조회
	public String select(@RequestParam("crop_policy_checkbox") String crop, @RequestParam("select_area_radio_2") String region, HttpServletRequest request, HttpSession session, Model model) {
		int calcRevenue = costService.calcRevenue(crop, region);
		
		String strCrop = crop;
		String strRegion = region;
		int revenue = calcRevenue;
		
		session.setAttribute("crop", strCrop);
		session.setAttribute("region", strRegion);
		session.setAttribute("revenue", revenue);
		
		int calcCost = costService.calcCost(crop, region);
		
		int cost = calcCost;
		
		session.setAttribute("cost", cost);
		
		int calcPolicy = costService.calcPolicy(region);
		
		List<Dto> listPolicy = costService.listPolicy(region);
		
		model.addAttribute("region", strRegion);
		model.addAttribute("cost", cost);
		model.addAttribute("policy_support", calcPolicy);
		model.addAttribute("list", listPolicy);
		
		return "/serviceCost";
	}
	
	@RequestMapping(value="/supply.do") // 정책 지원금 업데이트
	public String supply(@RequestParam("policy_support_radio") int policySupport, HttpSession session, Model model) {
		String crop = (String) session.getAttribute("crop");
        String region = (String) session.getAttribute("region");

        int uRevenue = costService.calcRevenue(crop, region);
        model.addAttribute("revenue", uRevenue);

        int uCost = costService.calcCost(crop, region);
        model.addAttribute("cost", uCost);

        model.addAttribute("policy_support", policySupport);
        session.setAttribute("policy_supports", policySupport);

        List<Dto> dtos = costService.listPolicy(region);
        model.addAttribute("list", dtos);
        
        return "/serviceCost";
    }
	
	@RequestMapping(value="/save.do") // 비용계산된 데이터 저장 후 수익 확인 페이지로 이동
	public String save(HttpSession session, Model model) {
		String crop = (String)session.getAttribute("crop");
		String region = (String)session.getAttribute("region");
		int revenue = (Integer)session.getAttribute("revenue");
		int cost = (Integer)session.getAttribute("cost");
		int policy_support = (Integer)session.getAttribute("policy_supports");
		int profit = revenue - cost + policy_support;
		
		costService.saveResult(crop, region, revenue, cost, policy_support, profit);
		
		return "/serviceProfit";
	}
	
	@Autowired
	IProfitService profitService;
	
	@RequestMapping(value = "/result.do")
    public @ResponseBody List<Integer> result(@RequestParam("select_crop_select") String targetCrop, @RequestParam("select_region_select") String targetRegion, @RequestParam("select_area_select") int IntegerStrArea, @RequestParam("select_work_select") int IntegerStrWork, Model model) {
        List<Dtos> profitList = profitService.profitList(targetCrop, targetRegion);
        System.out.println(profitList);

        int salary = 2720000;
        int revenue = profitList.get(0).getRevenue() * IntegerStrArea;
        int cost = profitList.get(0).getCost() * IntegerStrArea + (IntegerStrWork * salary);
        int policySupport = profitList.get(0).getPolicy_support();
        int profit = revenue - cost + policySupport;
        
        List<Integer> result = new ArrayList<Integer>();
        result.add(revenue);
        result.add(cost);
        result.add(policySupport);
        result.add(profit);
        
        System.out.println("result값 : " + result);

        model.addAttribute("profit_list", profitList);
        model.addAttribute("result", result);

        return result;
    }
	
	@RequestMapping(value="/servicePolicyCheck.do")
	public String policyCheck(Model model) {
		return "/servicePolicyCheck";
	}
	
	@RequestMapping(value="/festival.do")
	public String festival(Model model) {
		return "/festival";
	}
	
	
}
