package com.farm.myapp.revenue.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.farm.myapp.revenue.model.FarmAreaCropDto;
import com.farm.myapp.revenue.model.FarmCropAreaDto;
import com.farm.myapp.revenue.model.FarmCropDto;
import com.farm.myapp.revenue.model.FarmCropInfoDto;
import com.farm.myapp.revenue.model.FarmCropProfileDto;
import com.farm.myapp.revenue.model.FarmCropProfitDto;


@Repository
public class RevenueRepository implements IRevenueRepository{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public class CropListMapper implements RowMapper<FarmCropDto>{

		@Override
		public FarmCropDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmCropDto dtos = new FarmCropDto();
			dtos.setCrop_num(rs.getInt("crop_num"));
			dtos.setCrop_name(rs.getString("crop_name"));
			dtos.setCrop_eng(rs.getString("crop_eng"));
			return dtos;
		}
	}
	
	public class CropAreaListMapper implements RowMapper<FarmCropAreaDto>{

		@Override
		public FarmCropAreaDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmCropAreaDto dtos = new FarmCropAreaDto();
			dtos.setArea_eng(rs.getString("area_eng"));
			dtos.setArea_name(rs.getString("area_name"));
			return dtos;
		}
	}
	
	public class GetCropInfoMapper implements RowMapper<FarmCropInfoDto>{

		@Override
		public FarmCropInfoDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmCropInfoDto dtos = new FarmCropInfoDto();
			dtos.setPcost(rs.getDouble("pcost"));
			dtos.setDcost(rs.getDouble("dcost"));
			dtos.setTemp(rs.getDouble("temp"));
			dtos.setRain(rs.getDouble("rain"));
			dtos.setSun(rs.getDouble("sun"));
			dtos.setInsolation(rs.getDouble("insolation"));
			dtos.setHprice(rs.getDouble("hprice"));
			dtos.setGdp(rs.getDouble("gdp"));
			dtos.setArea(rs.getDouble("area"));
			dtos.setYield(rs.getDouble("yield"));
			return dtos;
		}	
	}
	
	public class GetCropProfitMapper implements RowMapper<FarmCropProfitDto>{

		@Override
		public FarmCropProfitDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmCropProfitDto dtos = new FarmCropProfitDto();
			dtos.setInterept(rs.getDouble("interept"));
			dtos.setPcost(rs.getDouble("pcost"));
			dtos.setDcost(rs.getDouble("dcost"));
			dtos.setTemp(rs.getDouble("temp"));
			dtos.setRain(rs.getDouble("rain"));
			dtos.setSun(rs.getDouble("sun"));
			dtos.setInsolation(rs.getDouble("insolation"));
			dtos.setHprice(rs.getDouble("hprice"));
			dtos.setGdp(rs.getDouble("gdp"));
			dtos.setArea(rs.getDouble("area"));
			dtos.setYield(rs.getDouble("yield"));
			return dtos;
		}
	}
	
	public class GetAreaCropMapper implements RowMapper<FarmAreaCropDto>{

		@Override
		public FarmAreaCropDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmAreaCropDto dtos = new FarmAreaCropDto();
			dtos.setArea_name(rs.getString("area_name"));
			dtos.setCrop_name(rs.getString("crop_name"));
			dtos.setCrop_eng(rs.getString("crop_eng"));
			return dtos;
		}
	}
	
	public class GetCropProfileMapper implements RowMapper<FarmCropProfileDto>{

		@Override
		public FarmCropProfileDto mapRow(ResultSet rs, int count) throws SQLException {
			FarmCropProfileDto dtos = new FarmCropProfileDto();
			dtos.setCropName(rs.getString("cropName"));
			dtos.setCropKor(rs.getString("cropKor"));
			dtos.setCropVariety(rs.getString("cropVariety"));
			dtos.setCropGrow(rs.getString("cropGrow"));
			dtos.setCropSpecial(rs.getString("cropSpecial"));
			return dtos;
		}
	}
	
	public class GetHpriceYieldMapper implements RowMapper<List<String>>{

		@Override
		public List<String> mapRow(ResultSet rs, int count) throws SQLException {
			List<String> dtos = new ArrayList<String>();
			String year = rs.getString("year");
			String hPrice = rs.getString("hPrice");
			String yield = rs.getString("yield");
			
			dtos.add(year);
			dtos.add(hPrice);
			dtos.add(yield);
			return dtos;
		}
		
	}
	
	@Override
	public List<FarmCropDto> cropList() {
		System.out.println("cropList() 실행");
		String sql = "SELECT * FROM cropList ORDER BY crop_name";
		
		return jdbcTemplate.query(sql, new RowMapper<FarmCropDto>() {
			@Override
			public FarmCropDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmCropDto dtos = new FarmCropDto();
				dtos.setCrop_num(rs.getInt("crop_num"));
				dtos.setCrop_name(rs.getString("crop_name"));
				dtos.setCrop_eng(rs.getString("crop_eng"));
				return dtos;
			}
		});	
	}
	
	@Override
	public List<FarmCropAreaDto> cropAreaList(String crop){
		System.out.println("cropAreaList() 실행");
		String sql = "SELECT * FROM area_Crops WHERE crop_eng=? ORDER BY area_name";
		
		return jdbcTemplate.query(sql, new Object[] {crop}, new RowMapper<FarmCropAreaDto>() {
			@Override
			public FarmCropAreaDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmCropAreaDto dtos = new FarmCropAreaDto();
				dtos.setArea_eng(rs.getString("area_eng"));
				dtos.setArea_name(rs.getString("area_name"));
				return dtos;
			}
		});
	}
	
	@Override
	public List<FarmCropInfoDto> getCropInfo(String selectCrop){
		System.out.println("getCropInfo() 실행");
		String sql = "SELECT * FROM " +selectCrop+ "_matrix WHERE year=2021";
		
		return jdbcTemplate.query(sql, new RowMapper<FarmCropInfoDto>() {

			@Override
			public FarmCropInfoDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmCropInfoDto dtos = new FarmCropInfoDto();
				dtos.setPcost(rs.getDouble("pcost"));
				dtos.setDcost(rs.getDouble("dcost"));
				dtos.setTemp(rs.getDouble("temp"));
				dtos.setRain(rs.getDouble("rain"));
				dtos.setSun(rs.getDouble("sun"));
				dtos.setInsolation(rs.getDouble("insolation"));
				dtos.setHprice(rs.getDouble("hprice"));
				dtos.setGdp(rs.getDouble("gdp"));
				dtos.setArea(rs.getDouble("area"));
				dtos.setYield(rs.getDouble("yield"));
				return dtos;
			}	
		});
	}
	
	@Override
	public List<FarmCropProfitDto> getCropProfit(String selectCrop){
		System.out.println("getCropProfit() 실행");
		String sql = "SELECT * FROM cropPrediction_matrix WHERE crop=?";
		return jdbcTemplate.query(sql, new Object[] {selectCrop}, new RowMapper<FarmCropProfitDto>() {

			@Override
			public FarmCropProfitDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmCropProfitDto dtos = new FarmCropProfitDto();
				dtos.setInterept(rs.getDouble("interept"));
				dtos.setPcost(rs.getDouble("pcost"));
				dtos.setDcost(rs.getDouble("dcost"));
				dtos.setTemp(rs.getDouble("temp"));
				dtos.setRain(rs.getDouble("rain"));
				dtos.setSun(rs.getDouble("sun"));
				dtos.setInsolation(rs.getDouble("insolation"));
				dtos.setHprice(rs.getDouble("hprice"));
				dtos.setGdp(rs.getDouble("gdp"));
				dtos.setArea(rs.getDouble("area"));
				dtos.setYield(rs.getDouble("yield"));
				return dtos;
			}
		});
	}
	
	@Override
	public List<Integer> getRevenues(String selectCrop){
		System.out.println("getRevenues() 실행");
		String sql = "SELECT revenue FROM "+selectCrop+"_matrix ORDER BY year";
		return jdbcTemplate.queryForList(sql, Integer.class);
	}

	@Override
	public List<FarmAreaCropDto> getAreaCrop(String areaCrop) {
		System.out.println("getAreaCrop() 실행");
		String sql = "SELECT * FROM area_crops WHERE area_eng=?";
		
		return jdbcTemplate.query(sql, new Object[] {areaCrop}, new RowMapper<FarmAreaCropDto>() {
			@Override
			public FarmAreaCropDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmAreaCropDto dtos = new FarmAreaCropDto();
				dtos.setArea_name(rs.getString("area_name"));
				dtos.setCrop_name(rs.getString("crop_name"));
				dtos.setCrop_eng(rs.getString("crop_eng"));
				return dtos;
			}
		});
	}
	
	@Override
	public List<FarmCropProfileDto> getCropProfile(String selectCrop){
		System.out.println("getCropProfile() 실행");
		String sql = "SELECT * FROM crop_profile WHERE cropName=?";
		return jdbcTemplate.query(sql, new Object[] {selectCrop}, new RowMapper<FarmCropProfileDto>() {
			@Override
			public FarmCropProfileDto mapRow(ResultSet rs, int count) throws SQLException {
				FarmCropProfileDto dtos = new FarmCropProfileDto();
				dtos.setCropName(rs.getString("cropName"));
				dtos.setCropKor(rs.getString("cropKor"));
				dtos.setCropVariety(rs.getString("cropVariety"));
				dtos.setCropGrow(rs.getString("cropGrow"));
				dtos.setCropSpecial(rs.getString("cropSpecial"));
				return dtos;
			}
		});
	}
	
	@Override
	public List<List<String>> getHpriceYield(String selectCrop){
		System.out.println("getHpriceYield() 실행");
		String sql = "SELECT year, hPrice, yield FROM "+selectCrop+"_matrix WHERE year IN (2017, 2018, 2019, 2020, 2021)";
		
		return jdbcTemplate.query(sql, new RowMapper<List<String>>() {

			@Override
			public List<String> mapRow(ResultSet rs, int count) throws SQLException {
				List<String> dtos = new ArrayList<String>();
				String year = rs.getString("year");
				String hPrice = rs.getString("hPrice");
				String yield = rs.getString("yield");
				
				dtos.add(year);
				dtos.add(hPrice);
				dtos.add(yield);
				return dtos;
			}
		});
	}
	
	
	


}
