package com.farm.myapp.userMgmt.service;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;

import com.farm.myapp.userMgmt.model.FarmMemberVO;

public interface IFarmUserMgmtService {
	void joinService(FarmMemberVO member);								//회원 가입 서비스
	void loginService(String id, String pw);							//로그인 서비스
	FarmMemberVO findIdService(String name, String ssn);				//ID찾기 서비스
	FarmMemberVO findPwService(String id, String  name, String  ssn);	//PW찾기 서비스
	FarmMemberVO getMemberInfo(String id);								//회원 정보 조회
	void modifyService(String id, String pw, String address, String eMail);
}
