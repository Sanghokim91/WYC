package com.farm.myapp.cost.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.farm.myapp.cost.model.Dto;


@Repository
public class CostRepository implements ICostRepository{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public class ListPolicyMapper implements RowMapper<Dto>{

		@Override
		public Dto mapRow(ResultSet rs, int count) throws SQLException {
			Dto dtos = new Dto();
			dtos.setRegion(rs.getString("region"));
			dtos.setPolicy_name(rs.getString("policy_name"));
			dtos.setPolicy_support(rs.getInt("policy_support"));
			return dtos;
		}	
	}
	
	@Override
	public int calcRevenue(String strCrop, String strRegion) {
		System.out.println("calcRevenue() 실행");
		String sql = "select revenue from TURN_TO_FARM_REVENUE_COST where crop=? and region=?";
		return jdbcTemplate.queryForObject(sql, Integer.class, strCrop, strRegion);
	}
	
	@Override
	public int calcCost(String strCrop, String strRegion) {
		System.out.println("calcCost() 실행");
		String sql = "select cost from TURN_TO_FARM_REVENUE_COST where crop=? and region=?";
		return jdbcTemplate.queryForObject(sql, Integer.class, strCrop, strRegion);
	}
	
	@Override
	public int calcPolicy(String strRegion) {
		System.out.println("calcPolicy() 실행");
		String sql = "select MIN(policy_support) from TURN_TO_FARM_POLICY where region=?";
		return jdbcTemplate.queryForObject(sql, Integer.class, strRegion);
	}
	
	@Override
	public List<Dto> listPolicy(String targetRegion){
		System.out.println("listPolicy() 실행");
		String sql = "select region, policy_name, policy_support from TURN_TO_FARM_POLICY where region=?";
		
		return jdbcTemplate.query(sql, new Object[] {targetRegion}, new RowMapper<Dto>() {

			@Override
			public Dto mapRow(ResultSet rs, int count) throws SQLException {
				Dto dtos = new Dto();
				dtos.setRegion(rs.getString("region"));
				dtos.setPolicy_name(rs.getString("policy_name"));
				dtos.setPolicy_support(rs.getInt("policy_support"));
				return dtos;
			}	
		});
	}
	
	@Override
	public void saveResult(String hCrop, String hRegion, int hRevenue, int hCost, int hPolicySupport, int hProfit) {
		System.out.println("saveResult() 실행");
		String sql = "insert into TURN_TO_FARM_HISTORY(id, crop, region, revenue, cost, policy_support, profit) values ('TestID', ?, ?, ?, ?, ?, ?)";
		
		jdbcTemplate.update(sql, hCrop, hRegion, hRevenue, hCost, hPolicySupport, hProfit);
	}
	
	
	
}
