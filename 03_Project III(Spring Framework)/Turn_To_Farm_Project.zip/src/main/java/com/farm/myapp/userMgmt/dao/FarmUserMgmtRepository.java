package com.farm.myapp.userMgmt.dao;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
//import org.springframework.ui.Model;

import com.farm.myapp.userMgmt.model.FarmMemberVO;


@Repository
public class FarmUserMgmtRepository implements IFarmUserMgmtRepository{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	HttpSession session;
	
	@Override
	public void joinService(FarmMemberVO member) {
		System.out.println("joinService 연결 성공 :" + member);
		member.setrDate(new Timestamp(System.currentTimeMillis()));

		if(confirmId(member.getId()) == MEMBER_EXISTENT) {
			System.out.println("아이디가 이미 존재합니다.");
		}else {
			int ri = insertMember(member);
			if(ri == MEMBER_LOGIN_SUCCESS) {
//				session.setAttribute("id", member.getId());
				System.out.println(member.getName() + "님 회원 가입을 축하합니다");
			}else {
				System.out.println("회원 가입에 실패 하였습니다");
			}
		}
	}

	@Override
	public int confirmId(String id) {
		String query = "select count(*) from WYCMembers where id = ?";
		int count = jdbcTemplate.queryForObject(query, new Object[]{id}, Integer.class);
		if(count == 1) {
			return 1;
		}else {
			return -1;
		}
		
	}

	@Override
	public int insertMember(FarmMemberVO member) {
		String query = "insert into WYCMembers values (?,?,?,?,?,?,?)";
		try{
		jdbcTemplate.update(query,
				member.getId(),
				member.getPw(),
				member.getName(),
				member.geteMail(),
				member.getrDate(),
				member.getSsn(),
				member.getAddress());
			return MEMBER_JOIN_SUCCESS;
		} catch (Exception e) {
        	e.printStackTrace();
        	return MEMBER_JOIN_FAIL;
    	}
	}

	@Override
	public void loginService(String id, String pw) {
		int checkNum = userCheck(id, pw);
		
		if(checkNum == MEMBER_LOGIN_IS_NOT) {
			System.out.println("아이디가 존재 하지 않습니다");
		}else if(checkNum == MEMBER_LOGIN_PW_NO_GOOD) {
			System.out.println("비밀번호가 틀립니다");
		}else if(checkNum == MEMBER_LOGIN_SUCCESS) {
			FarmMemberVO member = getMember(id);
			
			if(member == null) {
				System.out.println("존재하지 않는 회원입니다.");
			}else {
//				HttpSession session = request.getSession();
				String name = member.getName();
				System.out.println(name + "님 로그인 성공입니다");
				session.setAttribute("id", id);
				session.setAttribute("ValidMem", "yes");
			}
			
		}
		
	}

	@Override
	public int userCheck(String id, String pw) {
		int rsultInt = 0;
		String DBPw;
		
		String query = "SELECT pw FROM WYCMembers where id=?";
		DBPw = jdbcTemplate.queryForObject(query, new Object[]{id}, String.class);
		System.out.println("DBPw : " + DBPw);
		
		if(DBPw != null) {
			if(DBPw.equals(pw)) {
				rsultInt = MEMBER_JOIN_SUCCESS;
			}else {
				rsultInt = MEMBER_LOGIN_PW_NO_GOOD;
			}
		}else {
			rsultInt = MEMBER_LOGIN_IS_NOT;
		}
		return rsultInt;
	}

	@Override
	public FarmMemberVO getMember(String id) {
		System.out.println("getMember : " + id);
		String query = "select * from WYCMembers where id = ?";
		List<FarmMemberVO> members = jdbcTemplate.query(query, new Object[]{id}, new BeanPropertyRowMapper<FarmMemberVO>(FarmMemberVO.class));
		return members.get(0);
	}

	@Override
	public FarmMemberVO findIdService(String name, String ssn) {
		System.out.println("findIdService : " + name);
		String query = "SELECT id, name FROM WYCMembers WHERE name=? AND ssn=?";
		List<FarmMemberVO> findId = jdbcTemplate.query(query, new Object[] {name, ssn}, new BeanPropertyRowMapper<FarmMemberVO>(FarmMemberVO.class));
		return findId.get(0);
	}

	@Override
	public FarmMemberVO findPwService(String id, String name, String ssn) {
		System.out.println("findPwService : " + name);
		String query = "SELECT name,pw FROM WYCMembers WHERE id=? AND name=? AND ssn=?";
		List<FarmMemberVO> findId = jdbcTemplate.query(query, new Object[] {id, name, ssn}, new BeanPropertyRowMapper<FarmMemberVO>(FarmMemberVO.class));
		return findId.get(0);
	}

	@Override
	public FarmMemberVO getMemberInfo(String id) {
		System.out.println("getMemberInfo : " + id);
		String query = "SELECT * FROM WYCMembers WHERE id=?";
		List<FarmMemberVO> memberInfo= jdbcTemplate.query(query, new Object[] {id}, new BeanPropertyRowMapper<FarmMemberVO>(FarmMemberVO.class));
		return memberInfo.get(0);
	}

	@Override
	public void modifyService(String id, String pw, String address, String eMail) {
		String query = "UPDATE WYCMembers set pw=?, address=?, eMail=? WHERE id=?";
		jdbcTemplate.update(query, pw, address, eMail, id);
	}

}
	