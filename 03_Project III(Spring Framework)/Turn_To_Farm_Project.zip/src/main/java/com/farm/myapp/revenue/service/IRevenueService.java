package com.farm.myapp.revenue.service;

import java.util.List;

import com.farm.myapp.revenue.model.FarmAreaCropDto;
import com.farm.myapp.revenue.model.FarmCropAreaDto;
import com.farm.myapp.revenue.model.FarmCropDto;
import com.farm.myapp.revenue.model.FarmCropInfoDto;
import com.farm.myapp.revenue.model.FarmCropProfileDto;
import com.farm.myapp.revenue.model.FarmCropProfitDto;

public interface IRevenueService {
	
	List<FarmCropDto> cropList();
	List<FarmCropAreaDto> cropAreaList(String crop);
	List<FarmCropInfoDto> getCropInfo(String selectCrop);
	List<FarmCropProfitDto> getCropProfit(String selectCrop);
	List<Integer> getRevenues(String selectCrop);
	List<FarmAreaCropDto> getAreaCrop(String areaName);
	List<FarmCropProfileDto> getCropProfile(String selectCrop);
	List<List<String>> getHpriceYield(String selectCrop);

}
