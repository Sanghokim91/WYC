package com.farm.myapp.profit.dao;

import java.util.List;

import com.farm.myapp.profit.model.Dtos;

public interface IProfitRepository {

	List<Dtos> profitList(String targetCrop, String targetRegion);

}
