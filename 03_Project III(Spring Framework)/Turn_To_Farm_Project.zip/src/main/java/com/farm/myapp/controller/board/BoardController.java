package com.farm.myapp.controller.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.farm.myapp.board.model.BoardDto;
import com.farm.myapp.board.service.IBoardService;

@Controller
public class BoardController {
	
	@Autowired
	IBoardService boardService;
	
	@RequestMapping(value="/write_view.do") // 게시글 작성화면으로 이동
	public String index(Model model) {
		return "/board/boardWrite";
	}
	
	@RequestMapping(value="/write.do") // 게시글 입력 후 입력버튼 누르면 리스트로 이동
	public String write(BoardDto dto, Model model) {
		boardService.write(dto);
		return "redirect:/list.do";
	}
	
	@RequestMapping(value="/list.do") // 게시글 리스트 출력
	public String list(Model model) {
		List<BoardDto> list = boardService.list();
		model.addAttribute("list", list);
		return "/board/boardList";
	}
	
	@RequestMapping(value="/content_view.do") // 게시글 세부 정보화면으로 이동
	public String content_view(@RequestParam(value="bId", required=false, defaultValue="0") String strID, Model model) {
		BoardDto list = boardService.contentView(strID);
		model.addAttribute("content_view", list);
		return "/board/boardContent";
	}
	
	@RequestMapping(value="/modifyBoard.do") // 게시글 세부 정보화면에서 수정버튼을 누르면 수정페이지로 이동
	public String modifyBoard(@RequestParam(value="bId", required=false, defaultValue="0") String strID, Model model) {
		BoardDto list = boardService.contentView(strID);
		model.addAttribute("content_view", list);
		return "/board/boardModify";
	}
	
	@RequestMapping(value="/modify.do") // 수정내용 작성하고 수정버튼 누르면 수정되어 리스트로 이동
	public String modify(BoardDto dto, Model model) {
		boardService.modify(dto);
		return "redirect:/list.do";
	}
	
	@RequestMapping(value="/delete.do") // 삭제버튼 누르면 삭제되고 리스트로 이동
	public String delete(BoardDto dto, Model model) {
		boardService.delete(dto);
		return "redirect:/list.do";
	}
	
	@RequestMapping(value="/reply_view.do") // 게시글 세부 정보화면에서 댓글버튼 누르면 댓글작성 페이지로 이동
	public String reply_view(@RequestParam(value="bId", required=false, defaultValue="0") String strID, Model model) {
		BoardDto list = boardService.replyView(strID);
		model.addAttribute("reply_view", list);
		return "/board/boardReply";
	}
	
	@RequestMapping(value="/reply.do") // 댓글버튼 댓글 입력되고 리스트로 이동
	public String reply(BoardDto dto, Model model) {
		boardService.reply(dto);
		return "redirect:/list.do";
	}
	


}
