package com.farm.myapp.profit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.farm.myapp.profit.dao.IProfitRepository;
import com.farm.myapp.profit.model.Dtos;

@Service
public class ProfitService implements IProfitService{
	
	@Autowired
	IProfitRepository profitRepository;

	@Override
	public List<Dtos> profitList(String targetCrop, String targetRegion) {
		return profitRepository.profitList(targetCrop, targetRegion);
	}

}
