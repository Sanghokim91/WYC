package com.farm.myapp.cost.model;

public class Dto {
	
	String crop;
	String region;
	int revenue;
	int cost;
	int profit;
	int age;
	String year;
	int policy_support;
	String policy_name;
	
	public Dto() {
		
	}
	
	public Dto(int ex) {
		revenue = ex;
		cost = ex;
		policy_support = ex;
	}
	
	public Dto(String crop, String region) {
		this.crop = crop;
		this.region = region;
	}
	
	public Dto(String region, String policy_name, int policy_support) {
		this.region = region;
		this.policy_name = policy_name;
		this.policy_support = policy_support;
	}
	
	public Dto(String crop, String region, int revenue, int cost, int policy_support, int profit) {
		this.crop = crop;
		this.region = region;
		this.revenue = revenue;
		this.cost = cost;
		this.policy_support = policy_support;
		this.profit = profit;
	}

	public String getCrop() {
		return crop;
	}

	public void setCrop(String crop) {
		this.crop = crop;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public int getRevenue() {
		return revenue;
	}

	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getProfit() {
		return profit;
	}

	public void setProfit(int profit) {
		this.profit = profit;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public int getPolicy_support() {
		return policy_support;
	}

	public void setPolicy_support(int policy_support) {
		this.policy_support = policy_support;
	}

	public String getPolicy_name() {
		return policy_name;
	}

	public void setPolicy_name(String policy_name) {
		this.policy_name = policy_name;
	}
	
	private String label;
    private int value;

    public Dto(String label, int value) {
        this.label = label;
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public int getValue() {
        return value;
    }

}
