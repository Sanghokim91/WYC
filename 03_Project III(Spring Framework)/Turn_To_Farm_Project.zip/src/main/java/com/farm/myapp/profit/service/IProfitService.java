package com.farm.myapp.profit.service;

import java.util.List;

import com.farm.myapp.profit.model.Dtos;

public interface IProfitService {
	
	List<Dtos> profitList(String targetCrop, String targetRegion);

}
