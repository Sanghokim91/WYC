package com.farm.myapp.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.farm.myapp.board.dao.IBoardRepository;
import com.farm.myapp.board.model.BoardDto;

@Service
public class BoardService implements IBoardService{
	
	@Autowired
	IBoardRepository boardRepository;

	@Override
	public void write(BoardDto dto) {
		boardRepository.write(dto);
	}

	@Override
	public List<BoardDto> list() {
		return boardRepository.list();
	}

	@Override
	public BoardDto contentView(String strID) {
		return boardRepository.contentView(strID);
	}

	@Override
	public void modify(BoardDto dto) {
		boardRepository.modify(dto);
	}

	@Override
	public void delete(BoardDto dto) {
		boardRepository.delete(dto);
	}

	@Override
	public BoardDto replyView(String strID) {
		return boardRepository.replyView(strID);
	}

	@Override
	public void reply(BoardDto dto) {
		boardRepository.reply(dto);
	}

}
