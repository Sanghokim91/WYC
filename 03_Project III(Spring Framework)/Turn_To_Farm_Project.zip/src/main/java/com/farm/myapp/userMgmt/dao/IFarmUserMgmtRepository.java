package com.farm.myapp.userMgmt.dao;

import com.farm.myapp.userMgmt.model.FarmMemberVO;

public interface IFarmUserMgmtRepository {
	public static final int MEMBER_NONEXISTENT = 0;
	public static final int MEMBER_EXISTENT = 1;
	public static final int MEMBER_JOIN_FAIL = 0;
	public static final int MEMBER_JOIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_PW_NO_GOOD = 0;
	public static final int MEMBER_LOGIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_IS_NOT = -1;
	
	void joinService(FarmMemberVO member);								//회원 가입 서비스
	int confirmId(String id);											//회원가입 정보 중복 확인
	int insertMember(FarmMemberVO member);								//회원가입 정보 DB INSERT
	void loginService(String id, String pw);							//로그인 서비스
	int userCheck(String id, String pw);								//아이디 확인
	FarmMemberVO getMember(String id);									//일치하는 회원정보 SELECT
	FarmMemberVO findIdService(String name, String ssn);				//ID찾기
	FarmMemberVO findPwService(String id, String  name, String  ssn);	//PW찾기
	FarmMemberVO getMemberInfo(String id);
	void modifyService(String id, String pw, String address, String eMail);
}
