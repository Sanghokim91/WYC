package com.farm.myapp.cost.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.farm.myapp.cost.dao.ICostRepository;
import com.farm.myapp.cost.model.Dto;

@Service
public class CostService implements ICostService{
	
	@Autowired
	ICostRepository costRepository;

	@Override
	public int calcRevenue(String strCrop, String strRegion) {
		return costRepository.calcRevenue(strCrop, strRegion);
	}

	@Override
	public int calcCost(String strCrop, String strRegion) {
		return costRepository.calcCost(strCrop, strRegion);
	}

	@Override
	public int calcPolicy(String strRegion) {
		return costRepository.calcPolicy(strRegion);
	}

	@Override
	public List<Dto> listPolicy(String targetRegion) {
		return costRepository.listPolicy(targetRegion);
	}

	@Override
	public void saveResult(String hCrop, String hRegion, int hRevenue, int hCost, int hPolicySupport, int hProfit) {
		costRepository.saveResult(hCrop, hRegion, hRevenue, hCost, hPolicySupport, hProfit);
	}

}
