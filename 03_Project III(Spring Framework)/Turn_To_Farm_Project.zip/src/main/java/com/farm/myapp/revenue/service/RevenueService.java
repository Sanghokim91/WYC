package com.farm.myapp.revenue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.farm.myapp.revenue.dao.IRevenueRepository;
import com.farm.myapp.revenue.model.FarmAreaCropDto;
import com.farm.myapp.revenue.model.FarmCropAreaDto;
import com.farm.myapp.revenue.model.FarmCropDto;
import com.farm.myapp.revenue.model.FarmCropInfoDto;
import com.farm.myapp.revenue.model.FarmCropProfileDto;
import com.farm.myapp.revenue.model.FarmCropProfitDto;

@Service
public class RevenueService implements IRevenueService{
	
	@Autowired
	IRevenueRepository revenueRepository;

	@Override
	public List<FarmCropDto> cropList() {
		return revenueRepository.cropList();
	}

	@Override
	public List<FarmCropAreaDto> cropAreaList(String crop) {
		return revenueRepository.cropAreaList(crop);
	}

	@Override
	public List<FarmCropInfoDto> getCropInfo(String selectCrop) {
		return revenueRepository.getCropInfo(selectCrop);
	}

	@Override
	public List<FarmCropProfitDto> getCropProfit(String selectCrop) {
		return revenueRepository.getCropProfit(selectCrop);
	}

	@Override
	public List<Integer> getRevenues(String selectCrop) {
		return revenueRepository.getRevenues(selectCrop);
	}

	@Override
	public List<FarmAreaCropDto> getAreaCrop(String areaName) {
		return revenueRepository.getAreaCrop(areaName);
	}

	@Override
	public List<FarmCropProfileDto> getCropProfile(String selectCrop) {
		return revenueRepository.getCropProfile(selectCrop);
	}

	@Override
	public List<List<String>> getHpriceYield(String selectCrop) {
		return revenueRepository.getHpriceYield(selectCrop);
	}

}
