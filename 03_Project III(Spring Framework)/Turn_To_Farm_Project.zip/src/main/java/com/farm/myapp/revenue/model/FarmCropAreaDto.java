package com.farm.myapp.revenue.model;

public class FarmCropAreaDto {
//	int crop_num;
	String crop_name;
	String crop_eng;
	String crop_area;
	String area_eng;
	String area_name;
	
	
	public String getArea_eng() {
		return area_eng;
	}

	public void setArea_eng(String area_eng) {
		this.area_eng = area_eng;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public FarmCropAreaDto() {
	}
	
	public FarmCropAreaDto(String area_eng, String area_name) {
		this.area_eng = area_eng;
		this.area_name = area_name;
	}
	
	public FarmCropAreaDto(String crop_name, String crop_eng, String crop_area) {
		this.crop_name = crop_name;
		this.crop_eng = crop_eng;
		this.crop_area = crop_area;
	}

	public String getCrop_name() {
		return crop_name;
	}

	public void setCrop_name(String crop_name) {
		this.crop_name = crop_name;
	}

	public String getCrop_eng() {
		return crop_eng;
	}

	public void setCrop_eng(String crop_eng) {
		this.crop_eng = crop_eng;
	}

	public String getCrop_area() {
		return crop_area;
	}

	public void setCrop_area(String crop_area) {
		this.crop_area = crop_area;
	}
	
}
