package com.farm.myapp.cost.service;

import java.util.List;

import com.farm.myapp.cost.model.Dto;

public interface ICostService {
	
	int calcRevenue(String strCrop, String strRegion);
	int calcCost(String strCrop, String strRegion);
	int calcPolicy(String strRegion);
	List<Dto> listPolicy(String targetRegion);
	void saveResult(String hCrop, String hRegion, int hRevenue, int hCost, int hPolicySupport, int hProfit);

}
