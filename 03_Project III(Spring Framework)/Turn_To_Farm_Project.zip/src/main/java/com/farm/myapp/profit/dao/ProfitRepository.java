package com.farm.myapp.profit.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.farm.myapp.profit.model.Dtos;

@Repository
public class ProfitRepository implements IProfitRepository{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public class ProfitListMapper implements RowMapper<Dtos>{

		@Override
		public Dtos mapRow(ResultSet rs, int count) throws SQLException {
			Dtos dtos = new Dtos();
			dtos.setCrop(rs.getString("crop"));
			dtos.setRegion(rs.getString("region"));
			dtos.setRevenue(rs.getInt("revenue"));
			dtos.setCost(rs.getInt("cost"));
			dtos.setPolicy_support(rs.getInt("policy_support"));
			dtos.setProfit(rs.getInt("profit"));
			return dtos;
		}
	}
	
	@Override
	public List<Dtos> profitList(String targetCrop, String targetRegion){
		System.out.println("profitList() 실행");
		String sql = "select crop, region, revenue, cost, policy_support, profit from TURN_TO_FARM_HISTORY where crop=? and region=?";
		return jdbcTemplate.query(sql, new Object[] {targetCrop, targetRegion}, new RowMapper<Dtos>() {

			@Override
			public Dtos mapRow(ResultSet rs, int count) throws SQLException {
				Dtos dtos = new Dtos();
				dtos.setCrop(rs.getString("crop"));
				dtos.setRegion(rs.getString("region"));
				dtos.setRevenue(rs.getInt("revenue"));
				dtos.setCost(rs.getInt("cost"));
				dtos.setPolicy_support(rs.getInt("policy_support"));
				dtos.setProfit(rs.getInt("profit"));
				return dtos;
			}
		});
	}
	
	

}
