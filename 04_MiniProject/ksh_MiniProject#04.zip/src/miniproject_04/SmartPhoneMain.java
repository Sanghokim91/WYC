package miniproject_04;

import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) {

		SmartPhone smartphone = new SmartPhone();

		Scanner in = new Scanner(System.in);	

		System.out.println("# 데이터 2개를 입력합니다.");
		for (int i = 0; i < 2; i++) {
			smartphone.addAddr(smartphone.inputAddrData());
		}
		String name = "";

		while (true) {
			printMenu();
			
			int num = in.nextInt();
			switch (num) {
			case 1:
				smartphone.addAddr(smartphone.inputAddrData());
				break;
			case 2:
				smartphone.addAddr(smartphone.inputAddrData());
				break;
			case 3:
				smartphone.printAllAddr();
				break;
			case 4:
				smartphone.searchAddr(name);
				break;
			case 5:
				smartphone.deleteAddr(name);
				break;
			case 6:
				Addr newAddr = null;
				smartphone.editAddr(name, newAddr);
				break;
			case 7:
				System.out.println("프로그램이 종료됩니다.");
				System.exit(0);
				break;
			default:
				System.out.println("잘못된 숫자를 입력하였습니다. 다시 입력하세요.");
				break;

			}

		}

	}
	
	static void printMenu() {
		System.out.println("Contact----------");
		System.out.println(">>1. 연락처 등록(회사)");
		System.out.println(">>2. 연락처 등록(거래처)");
		System.out.println(">>3. 모든 연락처 출력");
		System.out.println(">>4. 연락처 검색");
		System.out.println(">>5. 연락처 삭제");
		System.out.println(">>6. 연락처 수정");
		System.out.println(">>7. 프로그램 종료");
		System.out.println("---------------------");
	}

}