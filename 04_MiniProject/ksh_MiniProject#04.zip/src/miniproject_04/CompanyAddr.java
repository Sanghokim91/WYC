package miniproject_04;

public class CompanyAddr extends Addr{
	
	public String companyName;
	public String departmentName;
	public String rank;
	
	public CompanyAddr(String name, String number, String email, String address, String group, String companyName, String departmentName, String rank) {
		super(name, number, email, address, group);
		this.companyName = companyName;
		this.departmentName = departmentName;
		this.rank = rank;
	}
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	@Override
	void printInfo() {
		System.out.println("이름 : " + getName());
		System.out.println("전화번호 : " + getNumber());
		System.out.println("이메일 : " + getEmail());
		System.out.println("주소 : " + getAddress());
		System.out.println("그룹 : " + getGroup());
		System.out.println("회사이름 : " + companyName);
		System.out.println("부서이름 : " + departmentName);
		System.out.println("직급 : " + rank);
	}
	
	
	
	

}