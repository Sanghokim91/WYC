package miniproject_04;

import java.util.Scanner;

public class SmartPhone {

	private String name;
	private String number;
	private String email;
	private String address;
	private String group;
	
	private String companyName;
	private String departmentName;
	private String rank;
	
	private String customerName;
	private String customerItem;

	int count = 0;

	Addr[] addr = new Addr[10]; // SmartPhone 클래스 배열
	Addr[] companyAddr = new CompanyAddr[10];
	Addr[] customerAddr = new CustomerAddr[10];
	

	Addr inputAddrData() {// 키보드로 부터 입력 받아 객체를 생성함
		Scanner sc = new Scanner(System.in);
		System.out.print("이름 : ");
		this.name = sc.nextLine();
		System.out.print("전화번호 : ");
		this.number = sc.nextLine();
		System.out.print("이메일 : ");
		this.email = sc.nextLine();
		System.out.print("주소 : ");
		this.address = sc.nextLine();
		System.out.print("그룹 : ");
		this.group = sc.nextLine();
		
		if(group.contentEquals("회사")) {
			System.out.print("회사이름 : ");
			this.companyName = sc.nextLine();
			System.out.print("부서이름 : ");
			this.departmentName = sc.nextLine();
			System.out.print("직급 : ");
			this.rank = sc.nextLine();
			
			return new CompanyAddr(name, number, email, address, group, companyName, departmentName, rank);
		}
		else {
			System.out.print("거래처이름 : ");
			this.customerName = sc.nextLine();
			System.out.print("부서이름 : ");
			this.customerItem = sc.nextLine();
			System.out.print("직급 : ");
			this.rank = sc.nextLine();
			
			return new CustomerAddr(name, number, email, address, group, customerName, customerItem, rank);
		}

	}

	void addAddr(Addr Addr) {// 배열에 연락처 객체 저장
		if(group.contentEquals("회사")) {
			companyAddr[count] = Addr;
			customerAddr[count] = null;
			addr[count] = companyAddr[count];
		}
		else {
			companyAddr[count] = null;
			customerAddr[count] = Addr;
			addr[count] = customerAddr[count];
		}
		
		count++;
		System.out.println(">>>데이터가 저장되었습니다." + count);
	}

	void printAddr(Addr Addr) {// 객체 정보 출력
		
		CompanyAddr company = (CompanyAddr) Addr;
		CustomerAddr customer = (CustomerAddr) Addr;
		
		System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s ", addr[count].getName(), addr[count].getNumber(), addr[count].getEmail(), addr[count].getAddress(), addr[count].getGroup());
		if(addr[count].getGroup().contentEquals("회사")) {
			System.out.printf("회사이름 : %s 부서이름 : %s 직급 : %s\n", company.companyName, company.departmentName, company.rank);
		}
		else {
			System.out.printf("회사이름 : %s 부서이름 : %s 직급 : %s\n", customer.customerName, customer.customerItem, customer.rank);
		}
		
	}

	void printAllAddr() {// 모든 연락처 출력
		for (int i = 0; i < count; i++) {
			System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s\n", addr[i].getName(), addr[i].getNumber(), addr[i].getEmail(), addr[i].getAddress(), addr[i].getGroup());
//			if(addr[count].getGroup().contentEquals("회사")) {
//				System.out.printf("회사이름 : %s 부서이름 : %s 직급 : %s\n", company.companyName, company.departmentName, company.rank);
//			}
//			else {
//				System.out.printf("회사이름 : %s 부서이름 : %s 직급 : %s\n", customer.customerName, customer.customerItem, customer.rank);
//			}
		}
	}

	void searchAddr(String name) {// 연락처 검색
		Scanner sc = new Scanner(System.in);
		System.out.println("검색할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		for (int i = 0; i < count; i++) {
			if (addr[i].getName().contentEquals(name)) {
				System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s\n", addr[i].getName(), addr[i].getNumber(), addr[i].getEmail(), addr[i].getAddress(), addr[i].getGroup());
			}
		}
	}

	void deleteAddr(String name) {// 연락처 삭제
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		for (int i = 0; i < addr.length; i++) {
			if (addr[i].getName().equals(name)) {
				for (int j = i; j < addr.length - 1; j++) {
					addr[j] = addr[j + 1];
				}
				System.out.println("삭제완료");
				break;
			}
		}
		count--;
	}

	void editAddr(String name, Addr newAddr) {// 연락처 수정
		Scanner sc = new Scanner(System.in);
		System.out.println("수정할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		newAddr = inputAddrData();
		for (int i = 0; i < count; i++) {
			if (addr[i].getName().equals(name)) {
				addr[i] = newAddr;
			}
		}
	}

}