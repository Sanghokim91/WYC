package miniproject_04;

public class CustomerAddr extends Addr{
	
	public String customerName;
	public String customerItem;
	public String rank;
	
	public CustomerAddr(String name, String number, String email, String address, String group, String customerName, String customerItem, String rank) {
		super(name, number, email, address, group);
		this.customerName = customerName;
		this.customerItem = customerItem;
		this.rank = rank;
	}
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerItem() {
		return customerItem;
	}

	public void setCustomerItem(String customerItem) {
		this.customerItem = customerItem;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	@Override
	void printInfo() {
		System.out.println("이름 : " + getName());
		System.out.println("전화번호 : " + getNumber());
		System.out.println("이메일 : " + getEmail());
		System.out.println("주소 : " + getAddress());
		System.out.println("그룹 : " + getGroup());
		System.out.println("거래처이름 : " + customerName);
		System.out.println("거래품목 : " + customerItem);
		System.out.println("직급 : " + rank);
	}

}