package miniproject_05;

public class SonataLowGrade extends Sonata{

	public SonataLowGrade(String color, String tire, int desplacement, String handle) {
		super(color, tire, desplacement, handle);
	}
	
	int tax = 0;
	
	@Override
	public void getSpec() {
		tax = 1000;
		System.out.println("******************");
		System.out.println("색상 : " + color);
		System.out.println("타이어 : " + tire);
		System.out.println("배기량 : " + desplacement);
		System.out.println("핸들 : " + handle);
		System.out.println("세금 : " + tax);
		System.out.println("******************");
		
	}

}
