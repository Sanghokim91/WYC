package miniproject_05;

public class MainClass {

	public static void main(String[] args) {
		
		SonataLowGrade lowGrade = new SonataLowGrade("블루", "일반타이어", 2000, "파워핸들");
		SonataHighGrade highGrade = new SonataHighGrade("레드", "광폭타이어", 2200, "파워핸들");
		
		lowGrade.getSpec();
		highGrade.getSpec();
		

	}

}
