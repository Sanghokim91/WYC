package miniproject_05;

public class CarSpecs {
	
	public static final String COLOR = "레드";
	public static final String TIRE = "일반타이어";
	public static final int DESPLACEMENT = 2000;
	public static final String HANDLE = "파워핸들";
	
	
	

}
