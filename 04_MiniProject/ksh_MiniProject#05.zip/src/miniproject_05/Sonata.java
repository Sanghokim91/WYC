package miniproject_05;

public abstract class Sonata extends CarSpecs{
	
	public String color;
	public String tire;
	public int desplacement;
	public String handle;
	
	public Sonata(String color, String tire, int desplacement, String handle) {
		this.color = color;
		this.tire = tire;
		this.desplacement = desplacement;
		this.handle = handle;
	}
	
	public abstract void getSpec();
	
}
