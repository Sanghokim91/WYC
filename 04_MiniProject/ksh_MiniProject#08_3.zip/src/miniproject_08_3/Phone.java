package miniproject_08_3;

import java.util.*;

public class Phone {
	
	Scanner in = new Scanner(System.in);
	
	Map<String, Addr> map = new HashMap<String, Addr>();
	
	Addr inputAddrData() {
		
		System.out.print("이름:");
		String name = in.nextLine();
		System.out.print("전화번호:");
		String phoneNumber = in.nextLine();
		System.out.print("이메일:");
		String email = in.nextLine();
		System.out.print("주소:");
		String address = in.nextLine();
		System.out.print("그룹:");
		String group = in.nextLine();
		
		return new Addr(name, phoneNumber, email, address, group);
	}
	
	void addAddr(Addr addr) {
		map.put(addr.getPhoneNumber(), addr);
		System.out.println("데이터가 저장되었습니다.");
	}
	
	void printAllAddr() {
		Set<Map.Entry<String, Addr>> entrySet = map.entrySet();
		Iterator<Map.Entry<String, Addr>> entryIterator = entrySet.iterator();
		while(entryIterator.hasNext()) {
			Map.Entry<String, Addr> entry = entryIterator.next();
			Addr value = entry.getValue();
			System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n",value.getName(), value.getPhoneNumber(), value.getEmail(), value.getAddress(), value.getGroup());
		}
			
	}
	
	void searchAddr(String phoneNumber) {
		System.out.print("검색할 전화번호를 입력하세요 : ");
		phoneNumber = in.nextLine();
		Set<Map.Entry<String, Addr>> entrySet = map.entrySet();
		Iterator<Map.Entry<String, Addr>> entryIterator = entrySet.iterator();
		while(entryIterator.hasNext()) {
			Map.Entry<String, Addr> entry = entryIterator.next();
			String key = entry.getKey();
			Addr value = entry.getValue();
			if(key.contentEquals(phoneNumber)) {
				System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n",value.getName(), value.getPhoneNumber(), value.getEmail(), value.getAddress(), value.getGroup());
			}
		}
	}
	
	void deleteAddr(String phoneNumber) {
		System.out.println("삭제할 전화번호를 입력하세요 : ");
		phoneNumber = in.nextLine();
		Set<Map.Entry<String, Addr>> entrySet = map.entrySet();
		Iterator<Map.Entry<String, Addr>> entryIterator = entrySet.iterator();
		while(entryIterator.hasNext()) {
			Map.Entry<String, Addr> entry = entryIterator.next();
			String key = entry.getKey();
			Addr value = entry.getValue();
			if(key.contentEquals(phoneNumber)) {
				map.remove(key);
				break;
			}
		}
		System.out.println("삭제가 완료되었습니다.");
	}
	
	void editAddr(String phoneNumber, Addr newAddr) {
		System.out.println("수정할 전화번호를 입력하세요.");
		phoneNumber = in.nextLine();
		newAddr = inputAddrData();
		Set<Map.Entry<String, Addr>> entrySet = map.entrySet();
		Iterator<Map.Entry<String, Addr>> entryIterator = entrySet.iterator();
		while(entryIterator.hasNext()) {
			Map.Entry<String, Addr> entry = entryIterator.next();
			String key = entry.getKey();
			Addr value = entry.getValue();
			if(key.contentEquals(phoneNumber)) {
				map.remove(key);
				map.put(phoneNumber, newAddr);
				break;
			}
		}
	}
	
}
