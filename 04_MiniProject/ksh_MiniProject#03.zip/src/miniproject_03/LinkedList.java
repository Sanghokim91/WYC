package miniproject_03;

public class LinkedList {
	
	private ListNode head;
	
	public LinkedList() {
		head = null;
	}
	
	public void insertMiddleNode(ListNode pre, String data) {
		ListNode newNode = new ListNode(data);
		newNode.link = pre.link;
		pre.link = newNode;
	}
	public void insertLastNode(String data) {
		ListNode newNode = new ListNode(data);
		
		if(head == null) {
			head = newNode;
		}
		else {//앞에 무언가있는대 그 무언가를 어떻게알아내야될까?이미 앞에 들어가져있는 무언가
			ListNode pre = new ListNode(data);
			
			newNode.link = pre.link;
			pre.link = newNode;
			
		}
		
	}
	public void deleteLastNode() {
		ListNode pre, temp;
		
		
	}
	public ListNode searchNode(String data) {
		ListNode temp = this.head;
		
		return temp;
	}
	public void reverseList() {
		ListNode next = head;
		ListNode current = null;
		ListNode pre = null;
		
		head = current;
	}
	
	public void printList() {
		ListNode temp = this.head;
		System.out.print("L = (");
		while(temp != null){
			System.out.print(temp.getData());
			temp = temp.link;
			if(temp != null) {
				System.out.print(", ");
			}
		}
		System.out.println(")");
	}

}
