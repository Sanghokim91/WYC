package miniproject_01;

public class AddrMain {

	public static void main(String[] args) {
		
		Addr address = new Addr("김상호", "010-8897-3761", "mikohgnas@naver.com", "서울", "친구");
		
		address.printInfo();
		System.out.println("---------------------------");
		System.out.println("그룹 정보 변경");
		System.out.println("---------------------------");
		address.setGroup("가족");
		address.printInfo();

	}

}
