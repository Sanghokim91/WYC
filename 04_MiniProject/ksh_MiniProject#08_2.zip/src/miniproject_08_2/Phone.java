package miniproject_08_2;

import java.util.*;

public class Phone {
	
	Scanner in = new Scanner(System.in);
	
	Set<Addr> set = new HashSet<Addr>();
	
	
	Addr inputAddrData() {
		
		System.out.print("이름:");
		String name = in.nextLine();
		System.out.print("전화번호:");
		String number = in.nextLine();
		System.out.print("이메일:");
		String email = in.nextLine();
		System.out.print("주소:");
		String address = in.nextLine();
		System.out.print("그룹:");
		String group = in.nextLine();
		
		return new Addr(name, number, email, address, group);
	}
	
	void addAddr(Addr addr) {
		set.add(addr);
		System.out.println("데이터가 저장되었습니다.");
	}
	
	void printAllAddr() {
		for(Addr value : set) {
			System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n",value.getName(), value.getNumber(), value.getEmail(), value.getAddress(), value.getGroup());
		}
	}
	
	void searchAddr(String name) {
		System.out.print("검색할 이름을 입력하세요 : ");
		name = in.nextLine();
		for(Addr value : set) {
			if(value.getName().contains(name)) {
				System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n",value.getName(), value.getNumber(), value.getEmail(), value.getAddress(), value.getGroup());
				break;
			}
		}
	}
	
	void deleteAddr(String name) {
		System.out.println("삭제할 이름을 입력하세요 : ");
		name = in.nextLine();
		for(Addr value : set) {
			if(value.getName().contains(name)) {
				set.remove(value);
				break;
			}
		}
		System.out.println("삭제가 완료되었습니다.");
	}
	
	void editAddr(String name, Addr newAddr) {
		System.out.println("수정할 연락처 이름을 입력하세요.");
		name = in.nextLine();
		newAddr = inputAddrData();
		for(Addr value : set) {
			if(value.getName().contains(name)) {
				set.remove(value);
				set.add(newAddr);
				break;
			}
		}
	}

}
