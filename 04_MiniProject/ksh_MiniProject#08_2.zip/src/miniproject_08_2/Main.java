package miniproject_08_2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Phone phone = new Phone();
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("# 데이터 2개를 입력합니다.");
		for(int i=0; i<2; i++) {
			phone.addAddr(phone.inputAddrData());
		}
		
		while(true) {
			printMenu();
			
			int num = in.nextInt();
			switch(num) {
			case 1:
				phone.addAddr(phone.inputAddrData());
				break;
			case 2:
				phone.printAllAddr();
				break;
			case 3:
				phone.searchAddr(null);
				break;
			case 4:
				phone.deleteAddr(null);
				phone.printAllAddr();
				break;
			case 5:
				phone.editAddr(null, null);
				phone.printAllAddr();
				break;
			case 6:
				System.out.println("프로그램이 종료됩니다.");
				return;
			default:
				System.out.println("잘못된 숫자를 입력하였습니다. 다시입력하세요.");
				break;
			}
		}

	}
	
	static void printMenu() {
		System.out.println("-----주소 관리 메뉴-----");
		System.out.println(">>1. 연락처 등록");
		System.out.println(">>2. 모든 연락처 출력");
		System.out.println(">>3. 연락처 검색");
		System.out.println(">>4. 연락처 삭제");
		System.out.println(">>5. 연락처 수정");
		System.out.println(">>6. 프로그램 종료");
		System.out.println("---------------------");
	}

}
