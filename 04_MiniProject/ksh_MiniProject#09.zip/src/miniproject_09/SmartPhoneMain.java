package miniproject_09;

import java.io.File;
import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) throws Exception{
		
		SmartPhone smartPhone = new SmartPhone();
		File dir = new File("C:/Temp/Dir");
		
		if(dir.exists() == false) {
			dir.mkdirs();
		}
		
		Scanner in = new Scanner(System.in);
		
		while(true) {
			printMenu();
			
			int num = in.nextInt();
			switch(num) {
			case 1:
				smartPhone.addAddr(smartPhone.inputAddrData());
				break;
			case 2:
				smartPhone.searchAddr(null);
				break;
			case 3:
				smartPhone.editAddr(null, null);
				break;
			case 4:
				smartPhone.deleteAddr(null);
				break;
			case 5:
				smartPhone.printAllAddr();
				break;
			case 6:
				smartPhone.saveFile();
				break;
			case 7:
				smartPhone.loadFile();
				break;
			case 8:
				System.out.println("프로그램이 종료됩니다.");
				return;
			default:
				System.out.println("잘못된 숫자를 입력하였습니다. 다시입력하세요.");
				break;
			}	
				
		}
		
	}
	
	static void printMenu() {
		System.out.println("------주소 관리 메뉴------");
		System.out.println(">>1. 연락처 등록");
		System.out.println(">>2. 연락처 검색");
		System.out.println(">>3. 연락처 수정");
		System.out.println(">>4. 연락처 삭제");
		System.out.println(">>5. 연락처 전체 리스트 보기");
		System.out.println(">>6. 연락처 파일 저장");
		System.out.println(">>7. 연락처 파일 로드");
		System.out.println(">>8. 프로그램 종료");
		System.out.println("-----------------------");
	}

}
