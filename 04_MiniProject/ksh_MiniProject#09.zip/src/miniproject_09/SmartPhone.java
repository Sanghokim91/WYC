package miniproject_09;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	
	List<Addr> list = new ArrayList<Addr>();
	
	Addr inputAddrData() {
		System.out.print("이름:");
		String name = in.nextLine();
		System.out.print("전화번호:");
		String number = in.nextLine();
		System.out.print("이메일:");
		String email = in.nextLine();
		System.out.print("주소:");
		String address = in.nextLine();
		System.out.print("그룹:");
		String group = in.nextLine();
		
		return new Addr(name, number, email, address, group);
	}
	
	void addAddr(Addr addr) {
		list.add(addr);
		System.out.println("데이터가 저장되었습니다.");
	}
	
	void printAllAddr() {
		for(Addr value : list) {
			System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n",value.getName(), value.getNumber(), value.getEmail(), value.getAddress(), value.getGroup());
		}
	}
	
	void searchAddr(String name) {
		System.out.print("검색할 이름을 입력하세요 : ");
		name = in.nextLine();
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getName().contentEquals(name)) {
				System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n", list.get(i).getName(), list.get(i).getNumber(), list.get(i).getEmail(), list.get(i).getAddress(), list.get(i).getGroup());
			}
		}
	}
	
	void deleteAddr(String name) {
		System.out.println("삭제할 이름을 입력하세요 : ");
		name = in.nextLine();
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getName().contentEquals(name)) {
				list.remove(i);
			}
		}
		System.out.println("삭제가 완료되었습니다.");
	}
	
	void editAddr(String name, Addr newAddr) {
		System.out.println("수정할 연락처 이름을 입력하세요.");
		name = in.nextLine();
		newAddr = inputAddrData();
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getName().contentEquals(name)) {
				list.set(i, newAddr);
			}
		}
	}
	
	void saveFile() throws Exception {
		FileOutputStream fos = new FileOutputStream("C:/Temp/Dir/test.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(inputAddrData());
		oos.flush();
		oos.close();
		fos.close();
	}
	
	void loadFile() throws Exception{
		FileInputStream fis = new FileInputStream("C:/Temp/Dir/test.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Addr addr = (Addr)ois.readObject();
		list.add(addr);
		System.out.printf("이름:%s, 전화번호:%s, 이메일:%s, 주소:%s, 그룹:%s\n", addr.getName(), addr.getNumber(), addr.getEmail(), addr.getAddress(), addr.getGroup());
		ois.close();
		fis.close();
	}

}
