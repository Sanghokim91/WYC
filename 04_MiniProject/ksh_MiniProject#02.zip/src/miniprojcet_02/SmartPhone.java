package miniprojcet_02;

import java.util.Scanner;

public class SmartPhone {

	private String name;
	private String number;
	private String email;
	private String address;
	private String group;

	int count = 0;

	Addr[] addr = new Addr[10];

	Addr inputAddrData() {// 키보드로 부터 입력 받아 객체를 생성함
		Scanner sc = new Scanner(System.in);
		System.out.print("이름 : ");
		this.name = sc.nextLine();
		System.out.print("전화번호 : ");
		this.number = sc.nextLine();
		System.out.print("이메일 : ");
		this.email = sc.nextLine();
		System.out.print("주소 : ");
		this.address = sc.nextLine();
		System.out.print("그룹 : ");
		this.group = sc.nextLine();
		
		return new Addr(name, number, email, address, group);

	}

	void addAddr(Addr Addr) {// 배열에 연락처 객체 저장
		addr[count] = Addr;
		count++;
		System.out.println(">>>데이터가 저장되었습니다." + count);
	}

	void printAddr(Addr Addr) {// 객체 정보 출력
		System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s\n", addr[count].getName(), addr[count].getNumber(), addr[count].getEmail(), addr[count].getAddress(), addr[count].getGroup());
	}

	void printAllAddr() {// 모든 연락처 출력
		for (int i = 0; i < count; i++) {
			System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s\n", addr[i].getName(), addr[i].getNumber(), addr[i].getEmail(), addr[i].getAddress(), addr[i].getGroup());
		}
	}

	void searchAddr(String name) {// 연락처 검색
		Scanner sc = new Scanner(System.in);
		System.out.println("검색할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		for (int i = 0; i < count; i++) {
			if (addr[i].getName().contentEquals(name)) {
				System.out.printf("이름 : %s 전화번호 : %s 이메일 : %s 주소 : %s 그룹 : %s\n", addr[i].getName(), addr[i].getNumber(), addr[i].getEmail(), addr[i].getAddress(), addr[i].getGroup());
			}
		}
	}

	void deleteAddr(String name) {// 연락처 삭제
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		for (int i = 0; i < addr.length; i++) {
			if (addr[i].getName().equals(name)) {
				for (int j = i; j < addr.length - 1; j++) {
					addr[j] = addr[j + 1];
				}
				System.out.println("삭제완료");
				break;
			}
		}
		count--;
	}

	void editAddr(String name, Addr newAddr) {// 연락처 수정
		Scanner sc = new Scanner(System.in);
		System.out.println("수정할 연락처 이름을 입력하시오.");
		name = sc.nextLine();
		newAddr = inputAddrData();
		for (int i = 0; i < count; i++) {
			if (addr[i].getName().equals(name)) {
				addr[i] = newAddr;
			}
		}
	}

}
