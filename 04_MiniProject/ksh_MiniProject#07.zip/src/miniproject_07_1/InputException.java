package miniproject_07_1;

public class InputException extends Exception {

	public InputException() {

	}

	public InputException(String message) {
		super(message);
	}

	public void print(int num) throws InputException{
		if (num != (int)num)// num이 int타입이 아닌경우
			throw new InputException("입력하신 데이터는 숫자가 아닙니다.");
			
		else {
			System.out.println("입력하신 데이터는 숫자가 맞습니다.");
		}
	}
	
//	public void print(String str) throws InputException{
//		throw new InputException("입력하신 데이터는 숫자가 아닙니다.");
//	}

}
