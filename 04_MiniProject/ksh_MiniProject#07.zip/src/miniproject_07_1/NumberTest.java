package miniproject_07_1;

import java.util.Scanner;

public class NumberTest {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		
		InputException input = new InputException();
		System.out.println("태어난 년도를 입력하시오.");
		int num = in.nextInt();
				
		try {
			
			input.print(num);

		}
		catch(InputException e) {
			String message = e.getMessage();
			System.out.println(message);
			input.printStackTrace();
			
		}
		
		
		in.close();

	}

}
