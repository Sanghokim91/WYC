package miniproject_07_2;

import java.util.Scanner;

public class InputTest {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		InputException input = new InputException();
		
		String name = in.nextLine();
		

	}

}
