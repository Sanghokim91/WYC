package miniproject_07_2;

public class InputException {
	
	public InputException() {

	}

	public InputException(String message) {
		
	}

}
