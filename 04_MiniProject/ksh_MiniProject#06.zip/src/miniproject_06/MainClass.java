package miniproject_06;

public class MainClass {

	public static void main(String[] args) {
		
		IFunction iFunction;
		iFunction = new APhone();
		iFunction.name();
		IFunction.call();
		iFunction.speed("3G");
		iFunction.remoteControl(false);
		
		iFunction = new BPhone();
		iFunction.name();
		IFunction.call();
		iFunction.speed("5G");
		iFunction.remoteControl(true);
		
		iFunction = new CPhone();
		iFunction.name();
		IFunction.call();
		iFunction.speed("4G");
		iFunction.remoteControl(false);

	}

}
