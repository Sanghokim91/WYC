package miniproject_06;

public interface IFunction {
	
	String THREE = "3G";
	String FOUR = "4G";
	String FIVE = "5G";
	
	void name();
	void speed(String speed);
	void remoteControl(boolean remote);
	
	static void call() {
		System.out.println("전화 가능합니다.");
	}

}
