package miniproject_06;

public class APhone implements IFunction{
	
	private String dataSpeed;
	@Override
	public void name() {
		System.out.println("A Phone");
	}
	
	@Override
	public void speed(String speed) {
		if(speed.equals("3G")) {
			this.dataSpeed = IFunction.THREE;
			System.out.println("불가능합니다." + dataSpeed + "입니다.");
		}
		if(speed.equals("4G")){
			this.dataSpeed = IFunction.FOUR;
			System.out.println("가능합니다." + dataSpeed + "입니다.");
		}
		if(speed.equals("5G")){
			this.dataSpeed = IFunction.FIVE;
			System.out.println("가능합니다." + dataSpeed + "입니다.");
		}
	}

	@Override
	public void remoteControl(boolean remote) {
		if(remote) {
			System.out.println("탑재 되어 있습니다");
		}
		else {
			System.out.println("미탑재 되어 있습니다.");
		}
		System.out.println("----------------------------");
	}

}